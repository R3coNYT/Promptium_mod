
package net.mcreator.promptium.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.HoeItem;

import net.mcreator.promptium.PromptiumElements;

@PromptiumElements.ModElement.Tag
public class PromptiumHoeItem extends PromptiumElements.ModElement {
	@ObjectHolder("promptium:promptiumhoe")
	public static final Item block = null;
	public PromptiumHoeItem(PromptiumElements instance) {
		super(instance, 10);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new HoeItem(new IItemTier() {
			public int getMaxUses() {
				return 500;
			}

			public float getEfficiency() {
				return 8f;
			}

			public float getAttackDamage() {
				return 0f;
			}

			public int getHarvestLevel() {
				return 8;
			}

			public int getEnchantability() {
				return 15;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}
		}, 1f, new Item.Properties().group(ItemGroup.TOOLS)) {
		}.setRegistryName("promptiumhoe"));
	}
}
