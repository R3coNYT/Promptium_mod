package net.mcreator.promptium.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.enchantment.Enchantments;

import net.mcreator.promptium.item.PromptiumIngotItem;
import net.mcreator.promptium.PromptiumElements;

@PromptiumElements.ModElement.Tag
public class BigswordMobIsHitWithItemProcedure extends PromptiumElements.ModElement {
	public BigswordMobIsHitWithItemProcedure(PromptiumElements instance) {
		super(instance, 29);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure BigswordMobIsHitWithItem!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			System.err.println("Failed to load dependency itemstack for procedure BigswordMobIsHitWithItem!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		itemstack.addEnchantment(Enchantments.SHARPNESS, (int) 10);
		itemstack.addEnchantment(Enchantments.FIRE_ASPECT, (int) 10);
		itemstack.addEnchantment(Enchantments.KNOCKBACK, (int) 10);
		itemstack.addEnchantment(Enchantments.UNBREAKING, (int) 10);
		itemstack.addEnchantment(Enchantments.UNBREAKING, (int) 10);
		if (entity instanceof PlayerEntity)
			((PlayerEntity) entity).addExperienceLevel((int) 10);
		if (entity instanceof PlayerEntity) {
			ItemStack _setstack = new ItemStack(PromptiumIngotItem.block, (int) (1));
			_setstack.setCount(1);
			ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), _setstack);
		}
	}
}
